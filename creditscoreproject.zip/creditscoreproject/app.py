# ==============================
# Streamlit Credit Risk Prediction App
# ==============================
import streamlit as st
import pandas as pd
import numpy as np
import joblib
import shap
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder

# ==============================
# PAGE CONFIG
# ==============================
st.set_page_config(
    page_title="Credit Risk Prediction",
    page_icon="💳",
    layout="wide"
)

st.title("💳 Credit Risk Prediction App")
st.write("Upload a CSV or enter details manually to predict credit risk and explain it using SHAP.")

# ==============================
# 1️⃣ Load trained model & features
# ==============================
model_path = r"C:\Users\admin\Desktop\creditscoreproject\models\model.pkl"
model = joblib.load(model_path)

print("Number of features:", model.n_features_in_)
print("Classes:", model.classes_)
print("Number of classes:", len(model.classes_))

# Load feature order used in training
feature_order_path = r"C:\Users\admin\Desktop\creditscoreproject\models\feature_encoders.pkl"
feature_order = joblib.load(feature_order_path)

# ==============================
# 2️⃣ Upload CSV or manual input
# ==============================
uploaded_file = st.file_uploader("Upload CSV", type="csv")

if uploaded_file:
    input_df = pd.read_csv(uploaded_file)
else:
    st.subheader("Or enter input manually:")
    input_dict = {
        "age": st.number_input("Age", min_value=18, max_value=100, value=40),
        "income": st.number_input("Income", min_value=0, max_value=1000000, value=100000),
        "sex": st.selectbox("Sex", ["male", "female"]),
        "employment_status": st.selectbox("Employment Status", ["employed", "unemployed", "self-employed"]),
        "credit_history": st.selectbox("Credit History", ["good", "bad"]),
        "repayment_behavior": st.selectbox("Repayment Behavior", ["on_time", "late"])
        # Add all features here exactly as in your CSV
    }
    input_df = pd.DataFrame([input_dict])

st.subheader("Input Data")
st.dataframe(input_df)

# ==============================
# 3️⃣ Encode categorical columns
# ==============================
for col in input_df.select_dtypes(include="object").columns:
    input_df[col] = LabelEncoder().fit_transform(input_df[col])


# ==============================
# 4️⃣ Align features with training
# ==============================

# Get feature names from training
if hasattr(model, "feature_names_in_"):
    feature_list = list(model.feature_names_in_)
else:
    # fallback if not available
    if isinstance(feature_order, dict):
        feature_list = list(feature_order.keys())
    else:
        feature_list = list(feature_order)

st.write("Features used during training:", feature_list)

# Encode categorical columns
for col in input_df.select_dtypes(include="object").columns:
    input_df[col] = LabelEncoder().fit_transform(input_df[col])

# Add missing columns
for col in feature_list:
    if col not in input_df.columns:
        input_df[col] = 0

# Keep ONLY training features
input_df = input_df[feature_list]

st.write("Final input shape:", input_df.shape)


# ==============================
# 5️⃣ Predict
# ==============================
sample = input_df

prediction = model.predict(sample)[0]
probability = model.predict_proba(sample)[0][1]

print("Prediction:", "High Risk" if prediction == 1 else "Low Risk")
print("Probability of Default:", round(probability * 100, 2), "%")


# ==============================
# 6️⃣ Explainable AI (SHAP)
# ==============================

st.subheader("🔍 Explainable AI - SHAP Explanation")

try:
    explainer = shap.TreeExplainer(model)
    shap_values = explainer(input_df)

    pred_class = prediction

    if len(model.classes_) > 2:
        shap_expl = shap.Explanation(
            values=shap_values.values[0][:, pred_class],
            base_values=shap_values.base_values[0][pred_class],
            data=input_df.iloc[0],
            feature_names=input_df.columns
        )
    else:
        shap_expl = shap.Explanation(
            values=shap_values.values[0],
            base_values=shap_values.base_values[0],
            data=input_df.iloc[0],
            feature_names=input_df.columns
        )

    fig, ax = plt.subplots()
    shap.plots.waterfall(shap_expl, show=False)
    st.pyplot(fig)
    plt.close()

except Exception as e:
    st.error("SHAP Explanation Failed")
    st.write(str(e))






